try{
	chrome.extension.sendRequest({name:"qzoneapp",reload:true}, function(response) {});
}catch(e){
}