try {
	chrome.extension.sendRequest({
				name : "qzoneapp",
				cookie : document.cookie
			}, function(response) {
			});
} catch (e) {
}

function _checkLink_() {
	if (!this.goApp) {
		setTimeout(_checkLink_, 100);
	}

	this.goApp = function(id, aname) {
		chrome.extension.sendRequest({
					name : "qzoneapp",
					goUrl : "http://user.qzone.qq.com/" + this._G.uin
							+ "/myhome/" + aname
				}, function(response) {
				});
		return false;
	};
}

if (/stoolbarapplist/.test(location)) {
	window.onload = function() {
		setTimeout(_checkLink_, 100)
	}
}
