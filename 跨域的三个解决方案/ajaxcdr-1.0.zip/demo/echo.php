<?
header("Cache-Control: no-cache, must-revalidate");
var_export($_REQUEST);
?>

